<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('FrontendModel');
		$this->load->library('session');
	}

	public function index()
	{
		header("Access-Control-Allow-Origin: *");
		if(!$this->session->has_userdata('visited')){
			$this->session->set_userdata('visited', TRUE);
			$this->FrontendModel->addWebDikunjungi();
		}
		$data['menu'] = 'profil';
		$data['profil'] = $this->FrontendModel->get('tb_profil_dmi')->row();
		$data['profil_pengurus'] = $this->FrontendModel->get('tb_profil_pengurus');
		$data['berita'] = $this->FrontendModel->getBeritaTerbaru(3);
		$this->load->view('frontend/view_home', $data);
	}

	public function masjid($tipologi=NULL)
	{
		header("Access-Control-Allow-Origin: *");
		$data['profil'] = $this->FrontendModel->get('tb_profil_dmi')->row();
		$data['menu'] = 'masjid';
		$data['tipologi'] = $tipologi;
		if($tipologi==NULL){
			$data['masjid'] = $this->FrontendModel->getWhere('tb_masjid', array('tipologi !='=>'Mushola'));
		}else{
			$data['masjid'] = $this->FrontendModel->getWhere('tb_masjid', array('tipologi'=>$tipologi));
		}
		$this->load->view('frontend/view_masjid', $data);
	}

	public function detailMasjid($id_masjid=NULL)
	{
		header("Access-Control-Allow-Origin: *");
		$data['profil'] = $this->FrontendModel->get('tb_profil_dmi')->row();
		$data['menu'] = 'masjid';
		$where = array('id_masjid'=>$id_masjid);
		$data['masjid'] = $this->FrontendModel->getWhere('tb_masjid', $where)->row();
		$data['galeri'] = $this->FrontendModel->getWhere('tb_galeri_masjid', $where);
		$data['kegiatan'] = $this->FrontendModel->getKegiatanByMasjid($where);
		$data['keuangan'] = $this->FrontendModel->getKeuanganByMasjid($id_masjid);
		$this->load->view('frontend/view_detail_masjid', $data);
	}

	public function mushola()
	{
		header("Access-Control-Allow-Origin: *");
		$data['profil'] = $this->FrontendModel->get('tb_profil_dmi')->row();
		$data['menu'] = 'masjid';
		$this->load->view('frontend/view_mushola', $data);
	}

	public function detailMushola()
	{
		header("Access-Control-Allow-Origin: *");
		$data['profil'] = $this->FrontendModel->get('tb_profil_dmi')->row();
		$data['menu'] = 'masjid';
		$this->load->view('frontend/view_detail_mushola', $data);
	}

	public function baca($kategori=NULL)
	{
		header("Access-Control-Allow-Origin: *");
		$data['profil'] = $this->FrontendModel->get('tb_profil_dmi')->row();
		$data['menu'] = 'khutbah';
		$data['kategori'] = $kategori;
		if($kategori==NULL){
			$data['baca'] = $this->FrontendModel->getBaca();
		}else{
			$data['baca'] = $this->FrontendModel->getBacaByKategori($kategori);
		}
		$data['post_terbaru'] = $this->FrontendModel->getBeritaTerbaru(5);
		$data['arsip'] = $this->FrontendModel->getArsip();
		$this->load->view('frontend/view_baca', $data);
	}

	public function bacaFull($id_khutbah=NULL)
	{
		header("Access-Control-Allow-Origin: *");
		$data['profil'] = $this->FrontendModel->get('tb_profil_dmi')->row();
		$data['menu'] = 'khutbah';
		$data['baca'] = $this->FrontendModel->getBacaById($id_khutbah);
		$data['post_terbaru'] = $this->FrontendModel->getBeritaTerbaru(5);
		$data['arsip'] = $this->FrontendModel->getArsip();
		$this->load->view('frontend/view_baca_full', $data);
	}

	public function downloadPDF($id_khutbah){

	}
}
